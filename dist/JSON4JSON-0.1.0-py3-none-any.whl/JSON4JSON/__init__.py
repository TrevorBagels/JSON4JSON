from JSON4JSON.JSON4JSON import JSON4JSON

__version__ = "0.1.0"
JSON4JSON = JSON4JSON #i think this is how it's done, right? it works, that's what matters now.